let addtoDoButton=document.getElementById('addtoDo');
let toDocontainer= document.getElementById('toDocontainer');
let Inputfield=document.getElementById('Inputfield');

addtoDoButton.addEventListener('click', function(){
var paragraph =document.createElement('p')
paragraph.classList.add('paragraph-styling');
paragraph.innerText=Inputfield.value;
toDocontainer.appendChild(paragraph);
Inputfield.value="";

paragraph.addEventListener('click',function(){
    paragraph.style.textDecoration="line-through";
    
})

paragraph.addEventListener('dblclick',function(){
    paragraph.removeChild();
    
})
})